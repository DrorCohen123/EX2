import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import FCQ1 from './Functional Comps/FCQ1'
import FCQ2 from './Functional Comps/FCQ2'
import FCQ3 from './Functional Comps/FCQ3'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
     
      <h2>Q1</h2>
     <FCQ1/><br/><br/>

     <h2>Q2</h2>
     <FCQ2></FCQ2><br/><br/>

     <h2>Q3</h2>

     <FCQ3></FCQ3>
   
    
    </>
  )
}

export default App
