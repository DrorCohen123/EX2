import { Component } from "react";

export default class FCQ1 extends Component {
  constructor(props) {
    super(props);
    this.state = { backColor: `white` };
  }

  changeColor = (event) => {
    this.setState({ backColor: event.currentTarget.id });
  };

  render() {
    return (
      <div
        style={{
          border: "solid black 2px",
          padding: 30,
          backgroundColor: this.state.backColor,
        }}
      >
        <button
          id="red"
          onClick={this.changeColor}
          style={{ backgroundColor: "red", margin: 10 }}
        >
          Red
        </button>
        <br />
        <button
          id="blue"
          onClick={this.changeColor}
          style={{ backgroundColor: "blue", margin: 10 }}
        >
          Blue
        </button>
        <button
          id="green"
          onClick={this.changeColor}
          style={{ backgroundColor: "green", margin: 10 }}
        >
          Green
        </button>
        <button
          id="pink"
          onClick={this.changeColor}
          style={{ backgroundColor: "pink", margin: 10 }}
        >
          Pink
        </button>
        <br />
        <button
          id="orange"
          onClick={this.changeColor}
          style={{ backgroundColor: "orange", margin: 10 }}
        >
          Orange
        </button>
        <button
          id="purple"
          onClick={this.changeColor}
          style={{ backgroundColor: "purple", margin: 10 }}
        >
          Purple
        </button>
        <button
          id="yellow"
          onClick={this.changeColor}
          style={{ backgroundColor: "yellow", margin: 10 }}
        >
          Yellow
        </button>
        <button
          id="gray"
          onClick={this.changeColor}
          style={{ backgroundColor: "gray", margin: 10 }}
        >
          Gray
        </button>
        <br />
      </div>
    );
  }
}
