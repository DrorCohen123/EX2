import { Component } from "react";

export default class FCQ2 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      str: "",
      fillLastName: "",
      fillFirstName: "",
      fillGrade: "",
    };
  }

  isPass = (e) => {
    this.setState({ fillGrade: "" });

    if (e.target.value == "") {
      this.setState({ str: "" });
    } else if (e.target.value < 555) {
      this.setState({ str: `Try again next year` });
      this.setState({ fillGrade: "" });
    } else {
      this.setState({ str: "Congratulations, you can accepted for studies" });
      this.setState({ fillGrade: "" });
    }
  };

  gradeCheck = (e) => {
    if (e.target.value == "") {
      this.setState({ fillGrade: "You must fill in grade" });
    } else {
      this.setState({ fillGrade: "" });
    }
  };

  firstNameCheck = (e) => {
    if (e.target.value == "") {
      this.setState({ fillFirstName: "You must fill in a first name" });
    } else {
      this.setState({ fillFirstName: "" });
    }
  };

  lastNameCheck = (e) => {
    if (e.target.value == "") {
      this.setState({ fillLastName: "You must fill in a last name" });
    } else {
      this.setState({ fillLastName: "" });
    }
  };
  lastNameBlur = (e) => {
    this.setState({ fillLastName: "" });
  };

  firstNameBlur = (e) => {
    this.setState({ fillFirstName: "" });
  };

  render() {
    return (
      <div style={{ border: "solid black 3px" }}>
        <h2>Form</h2>
        <p style={{ color: "red" }}>{this.state.fillLastName}</p>
        Last name:{" "}
        <input
          type="text"
          onFocus={this.lastNameCheck}
          onBlur={this.lastNameBlur}
        ></input>{" "}
        <br />
        <br />
        <p style={{ color: "red" }}>{this.state.fillFirstName}</p>
        First name :{" "}
        <input
          type="text"
          onFocus={this.firstNameCheck}
          onBlur={this.firstNameBlur}
        ></input>
        <br />
        <br />
        <p style={{ color: "red" }}>{this.state.fillGrade}</p>
        Grade:{" "}
        <input
          type="number"
          min="0"
          max="800"
          onFocus={this.gradeCheck}
          onBlur={this.isPass}
        ></input>
        <br />
        <h4 style={{ color: "red" }}>{this.state.str}</h4>
      </div>
    );
  }
}
