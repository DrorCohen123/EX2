import { Component } from "react";

export default class FCQ3 extends Component{
    
    constructor(props){
        super(props);
        this.state= {tableWidth: '100%'} 
       

    }

    width50 =(event)=>{
        this.setState({tableWidth: '50%'});
    }

    
    width100 =(event)=>{
        this.setState({tableWidth: '100%'});        
    }

    render(){

    return(

       <div>
            <table style={{border: 'solid black 2px', borderCollapse: `collapse`,
             width: this.state.tableWidth , height:200}} onClick={this.width50} onDoubleClick={this.width100} >
                <tr style={{border:'solid black 2px'}}>
                    <td style={{border:'solid black 2px'}}>abc</td>
                    <td style={{border:'solid black 2px'}}>abc</td>
                    <td style={{border:'solid black 2px'}}>abc</td>
                </tr>
                <tr>
                    <td style={{border:'solid black 2px'}}>abc</td>
                    <td style={{border:'solid black 2px'}}>abc</td>
                    <td style={{border:'solid black 2px'}}>abc</td>
                </tr>
            </table>
        </div>
    );



    }

}